document.write(`
  <header>
    <img alt='logo' class="logo" src="{logoUrl}">
  </header>
`);