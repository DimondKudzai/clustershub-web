def get_all_users():
    users = [
    {
    "name": "Dimond",
    "description": "A well known dev.",
    "website": "http://smartlearning.liveblog365.com/dimond",
    "email": "diamondkudzai70@gmail.com",
    "phone": "012 345 6789",
    "image" : "image1.png"
    },
    {
    "name": "JohnDoe",
    "description": "A musician and Description for second user.",
    "website": "https://github.com/dimondkudzai",
    "email": "contact@secoggnduser.co.za",
    "phone": "+2712 345 6790",
    "image" : "image2.png"
    },
    {
    "name": "ChrisVoiloe",
    "description": "Here is Description for Chris user.",
    "website": "http://smartlearning.liveblog365.com/dimond/index.html",
    "email": "contact@seconduser.co.za",
    "phone": "+2712 345 6790",
    "image" : "image3.png"
    },
    {
    "name": "VictorPose",
    "description": "Description for Victor Pose.",
    "website": "www.sPruser.co.za",
    "email": "contact@seconfghduser.co.za",
    "phone": "012 345 6790",
    "image" : "image4.png"
    },
    {
    "name": "KnosiDube",
    "description": "A lawyer in SA.",
    "website": "www.sgueconduser.co.za",
    "email": "contact@setcondghuser.co.za",
    "phone": "+26312 345 6790",
    "image" : "image5.png"
    }
    ]
    return users