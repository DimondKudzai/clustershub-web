function toggleMenu() {
 const nav = document.getElementById("navLinks");
 nav.classList.toggle("active");
 }
 